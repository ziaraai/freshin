import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import ReactCountryFlag from 'react-country-flag';
import { Button } from '@/components/ui/button';
import { CreateLanguageModal } from './create-language-modal';
import { useLayout } from '@/contexts/LayoutContext';

import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuGroup,
    DropdownMenuItem,
    DropdownMenuTrigger,
    DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { Globe, Plus, Settings } from 'lucide-react';
import { usePage, router } from '@inertiajs/react';
import { hasRole } from '@/utils/authorization';
import { toast } from './custom-toast';
import { isDemoMode, setCookie } from '@/utils/cookies';


interface Language {
    code: string;
    name: string;
    countryCode: string;
    enabled?: boolean;
}

export function LanguageSwitcher() {
    const { i18n, t } = useTranslation();
    const { auth, globalSettings, userLanguage } = usePage().props as any;
    const { setPosition } = useLayout();
    const { updatePosition } = useLayout();
    // Initialize with user's language immediately

    const [currentLanguage, setCurrentLanguage] = useState<Language | null>(() => {
        const languages = (globalSettings?.availableLanguages || []).filter((l: any) => l.enabled !== false);
        if (userLanguage) {
            const lang = languages.find((l: Language) => l.code === userLanguage);
            if (lang) {
                return lang;
            }
        }

        return languages[0] || null;
    });

    const [showCreateModal, setShowCreateModal] = useState(false);

    const availableLanguages = globalSettings?.availableLanguages || [];
    const isAuthenticated = !!auth?.user;
    const userRoles = auth?.user?.roles?.map((role: any) => role.name) || [];
    const isSuperAdmin = isAuthenticated && hasRole('superadmin', userRoles);
    useEffect(() => {
        const languages = (availableLanguages || []).filter((l: any) => l.enabled !== false);

        if (userLanguage && i18n.language !== userLanguage) {
            i18n.changeLanguage(userLanguage, () => {
                const lang = languages.find((l: Language) => l.code === userLanguage) || languages[0];
                setCurrentLanguage(lang);
            });
        } else {
            const lang = languages.find((l: Language) => l.code === i18n.language) || languages[0];
            setCurrentLanguage(lang);
        }
    }, [availableLanguages, userLanguage]);

    // Separate effect to update current language when i18n changes
    useEffect(() => {
        const languages = (availableLanguages || []).filter((l: any) => l.enabled !== false);
        const lang = languages.find((l: Language) => l.code === i18n.language) || languages[0];
        setCurrentLanguage(lang);
    }, [i18n.language, availableLanguages]);

    // const handleLanguageChange = (languageCode: string) => {
    //     const lang = availableLanguages.find((l: Language) => l.code === languageCode);
    //     if (lang) {
    //         setCurrentLanguage(lang);
    //         i18n.changeLanguage(languageCode);

    //         // RTL language detection
    //         const rtlLanguages = ['ar', 'he'];
    //         const isRtl = rtlLanguages.includes(languageCode);
    //         const newDirection = isRtl ? 'right' : 'left';

    //         // Always keep document direction as LTR to prevent sidebar issues
    //         document.documentElement.dir = 'ltr';
    //         document.documentElement.setAttribute('dir', 'ltr');

    //         // Update layout context
    //         setPosition(newDirection);

    //         // Save to backend or cookies
    //         if (isAuthenticated && !isDemoMode()) {
    //             // Save language change for authenticated non-demo users
    //             router.post(route('languages.change'), {
    //                 language: languageCode
    //             }, {
    //                 preserveScroll: true,
    //                 onSuccess: () => {
    //                     // After language is saved, update layoutDirection if RTL
    //                     if (isRtl || (!isRtl && globalSettings?.layoutDirection === 'right')) {
    //                         router.post(route('settings.brand.update'), {
    //                             settings: {
    //                                 layoutDirection: newDirection
    //                             }
    //                         }, {
    //                             preserveScroll: true,
    //                             onError: (errors) => {
    //                             }
    //                         });
    //                     }
    //                 },
    //                 onError: (errors) => {
    //                 }
    //             });
    //         } else {
    //             // For demo mode or non-authenticated users, save to cookies
    //             setCookie('app_language', languageCode);
    //             setCookie('layoutDirection', newDirection);
    //         }
    //     }
    // };


    // RTL languages list


    const rtlLanguages = ['ar', 'he'];

    const handleLanguageChange = async (languageCode: string) => {
        const lang = availableLanguages.find((l: Language) => l.code === languageCode);
        if (lang) {
            setCurrentLanguage(lang);
            try {
                await i18n.changeLanguage(languageCode);

                const isRtl = rtlLanguages.includes(languageCode);
                const newDirection = isRtl ? 'right' : 'left';

                document.documentElement.dir = 'ltr';
                document.documentElement.setAttribute('dir', 'ltr');

                updatePosition(newDirection as 'left' | 'right');

                // Save layoutDirection to database/cookies when RTL language is selected
                if (isAuthenticated && !isDemoMode()) {
                    // Save language change for authenticated non-demo users
                    router.post(route('user.language.update'), {
                        language: languageCode
                    }, {
                        preserveScroll: true,
                        onError: (errors) => {
                            toast.error('Failed to save language preference:', errors);
                        }
                    });
                } else {
                    // For demo mode or non-authenticated users, save to cookies
                    // setCookie('layoutDirection', newDirection);
                    setCookie('app_language', languageCode);
                    setCookie('layoutPosition', newDirection);
                }

                window.dispatchEvent(new CustomEvent('languageChanged', {
                    detail: { language: languageCode, direction: newDirection }
                }));

                window.dispatchEvent(new Event('resize'));
            } catch (error) {
            }
        }
    };
    return (
        <>
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center gap-1.5 sm:gap-2 rounded-md border shadow-sm bg-white dark:bg-gray-900 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer h-9 px-2 sm:px-2.5">
                        <Globe className="h-4 w-4 shrink-0 text-gray-600 dark:text-gray-400 hidden lg:inline-block" />
                        {currentLanguage && (
                            <>
                                <span className="text-sm font-medium hidden min-[1440px]:inline-block">
                                    {currentLanguage.name}
                                </span>
                                <ReactCountryFlag
                                    countryCode={currentLanguage.countryCode}
                                    svg
                                    style={{ width: '1.2em', height: '1.2em' }}
                                />
                            </>
                        )}
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                    <DropdownMenuGroup>
                        <div className="max-h-48 overflow-y-auto">
                            {(availableLanguages || []).filter((language: any) => language.enabled !== false).map((language: Language) => (
                                <DropdownMenuItem
                                    key={language.code}
                                    onClick={() => handleLanguageChange(language.code)}
                                    className={`flex items-center gap-2 ${currentLanguage?.code === language.code ? 'bg-accent' : ''}`}
                                >
                                    <ReactCountryFlag
                                        countryCode={language.countryCode}
                                        svg
                                        style={{ width: '1.2em', height: '1.2em' }}
                                    />
                                    <span>{language.name}</span>
                                </DropdownMenuItem>
                            ))}
                        </div>
                    </DropdownMenuGroup>
                    {isSuperAdmin && (
                        <>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                                onClick={() => setShowCreateModal(true)}
                                className="justify-start text-primary font-semibold cursor-pointer"
                            >
                                <Plus className="h-4 w-4 mr-2" />
                                {t('Create Language')}
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild className="justify-start text-primary font-semibold cursor-pointer">
                                <a href={route('manage-language')} rel="noopener noreferrer">
                                    <Settings className="h-4 w-4 mr-2" />
                                    {t('Manage Language')}
                                </a>
                            </DropdownMenuItem>
                        </>
                    )}
                </DropdownMenuContent>
            </DropdownMenu>
            <CreateLanguageModal
                open={showCreateModal}
                onOpenChange={setShowCreateModal}
                onSuccess={() => setShowCreateModal(false)}
            />
        </>
    );
}
