#!/usr/bin/env python3
"""Restore this export onto a clean checkout at the recorded base commit."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

bundle = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else None
if repo is None:
    raise SystemExit('Usage: python3 restore.py /path/to/freshin')
manifest = json.loads((bundle / 'manifest.json').read_text())
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)
if Path(git('rev-parse', '--show-toplevel').decode().strip()).resolve() != repo:
    raise SystemExit('Target must be the repository root.')
if git('rev-parse', 'HEAD').decode().strip() != manifest['base_commit']:
    raise SystemExit('Wrong base commit. Preserve existing work and use the recorded base commit.')
if git('status', '--porcelain', '--untracked-files=all').strip():
    raise SystemExit('Checkout is not clean. Preserve existing changes before restoration.')
for entry in manifest['files']:
    relative = Path(entry['path'])
    target = repo / relative
    if relative.is_absolute() or '..' in relative.parts or not target.resolve().is_relative_to(repo):
        raise SystemExit('Unsafe path in manifest.')
    if target.is_symlink():
        raise SystemExit('Refusing to replace a symlink.')
    if entry['status'] == 'deleted':
        git('ls-files', '--error-unmatch', '--', entry['path'])
subprocess.run(['git', 'apply', '--check', str(bundle / 'changes.patch')], cwd=repo, check=True)
subprocess.run(['git', 'apply', str(bundle / 'changes.patch')], cwd=repo, check=True)
for entry in manifest['files']:
    target = repo / entry['path']
    if entry['status'] == 'deleted':
        target.unlink()
    elif hashlib.sha256(target.read_bytes()).hexdigest() != entry['sha256']:
        raise SystemExit('Restored file checksum mismatch: ' + entry['path'])
print('Restored local modifications, additions and deletions. No commit or push performed.')
