REPRISE FRESHIN — MODIFICATIONS LOCALES

Dépôt : ziaraai/freshin
Commit de base : 060b9b29537de97ea1ab4fe1980fa823eaabeaa6

Contenu :
- changes.patch : modifications des fichiers existants et nouveaux fichiers.
  Les suppressions sont listées séparément, sans exporter leur ancien contenu.
- files/ : copie des fichiers ajoutés/modifiés, aux chemins du dépôt.
- manifest.json : liste des fichiers, statuts et sommes SHA-256.
- deleted-files.txt : chemins des fichiers supprimés.

RESTAURATION
Extraire l'archive hors du dépôt, puis, depuis un checkout propre au commit
ci-dessus (sans écraser de travail existant) :
  python3 /chemin/vers/restore.py /chemin/vers/freshin
Le script vérifie le commit de base et exige un checkout propre, puis applique
le patch et les suppressions listées. Il ne fait ni commit ni push.
Ne pas utiliser ensuite « git reset --hard » ou « git clean ».
Si le checkout contient déjà ces modifications, ne pas réappliquer le patch.
Copier files/ seul ne suffit pas à reproduire les suppressions.

TRAVAIL À TERMINER
Horaires et jours de commande en Europe/London, choix d'une date de livraison,
contrôles serveur avant commande. Garder Stripe ET paiement à la livraison
(COD) pour les clients. Autres passerelles en cours de suppression ; abonnements
SaaS conservés avec Stripe. Conserver le contact WhatsApp indépendant.
Les 47 tests horaires/date (149 assertions) et la compilation avaient réussi
AVANT la simplification des paiements. Ne pas présenter ces résultats comme
une validation des derniers changements Stripe/COD. Relancer installation,
tests et compilation après revue des routes, helpers, paramètres et imports.
Consulter docs/ordering-schedule.md et tests/Unit/OrderingSchedule*.

SÉCURITÉ ET ÉTAT
Aucun .env, fichier d'identifiants, base de données, vendor, node_modules,
.git ou répertoire de runtime local n'est inclus. Les scripts de migration
sont du code source et sont inclus. Les identifiants factices des tests ne
sont pas des identifiants réels. Aucune publication, aucun push GitHub.
Archive de modifications uniquement : le dépôt de base reste nécessaire.
Le patch a été vérifié sur un index Git temporaire, sans modifier le checkout.
